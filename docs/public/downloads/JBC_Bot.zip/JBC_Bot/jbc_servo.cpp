#include "jbc_servo.h"
#include <avr/interrupt.h>

extern "C" void jbc_motor_compute_pid(void) __attribute__((weak));

static volatile uint8_t servo_state = 0;
static volatile uint8_t servo_rest_counter = 0;
static volatile uint8_t _servo_ticks[2] = {94, 94};

ISR(TIMER2_COMPA_vect) {
  switch (servo_state) {
  case 0:
    PORTC &= ~(1 << 1);
    PORTC |= (1 << 2);
    OCR2A = _servo_ticks[1];
    TCNT2 = 0;
    servo_state = 1;
    break;
  case 1:
    PORTC &= ~(1 << 2);
    OCR2A = 250;
    TCNT2 = 0;
    servo_state = 2;
    servo_rest_counter = 0;
    break;
  default:
    servo_rest_counter++;
    if (jbc_motor_compute_pid) jbc_motor_compute_pid(); // Called every ~4ms for 250Hz observer/PID
    if (servo_rest_counter > 3) {
      PORTC |= (1 << 1);
      OCR2A = _servo_ticks[0];
      TCNT2 = 0;
      servo_state = 0;
    }
    break;
  }
}

void jbc_servo_init() {
  DDRC |= (1 << 1) | (1 << 2); // PC1 and PC2 (A1 and A2) as output
  TCCR2A = 0;
  TCCR2B = 0x06;
  TIMSK2 |= (1 << OCIE2A);
  OCR2A = 100;
}

void jbc_servo_set(uint8_t index, uint8_t angle) {
  if (angle > 180) angle = 180;
  _servo_ticks[index & 1] = 31 + ((angle * 177) >> 8);
}
