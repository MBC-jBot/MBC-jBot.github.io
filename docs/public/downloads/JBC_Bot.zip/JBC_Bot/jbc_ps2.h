#ifndef JBC_PS2_H
#define JBC_PS2_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_ps2_init();
bool jbc_ps2_is_connected();
bool jbc_ps2_is_active();
bool jbc_ps2_is_attempted();
bool jbc_ps2_button_pressed(uint16_t mask);
uint8_t jbc_ps2_get_stick(uint8_t stick);
bool jbc_ps2_read();

#ifdef __cplusplus
}
#endif

#endif // JBC_PS2_H
