#ifndef JBC_BOT_H
#define JBC_BOT_H

#include <Arduino.h>
#include "jbc_config.h"

// 引入極度優化的靜態子模組
#include "jbc_motor.h"
#include "jbc_servo.h"
#include "jbc_led.h"
#include "jbc_i2c.h"
#include "jbc_ps2.h"
#include "jbc_hw.h"
#include "jbc_oled.h"

class JBC_Bot {
  public:
    JBC_Bot();
    void begin();                                       
    
    // --- 馬達與運動控制 ---
    inline void setMotor(uint8_t index, int8_t speed) { jbc_motor_set(index, speed); }
    inline void setMotors(int8_t speedL, int8_t speedR) { jbc_motor_set_both(speedL, speedR); }
    inline void setMotorSync(int sync) { jbc_motor_set_sync(sync); }
    inline void moveDistance(float cm, int8_t speedL, int8_t speedR) { jbc_motor_move_distance((int32_t)(cm * 10), speedL, speedR); }
    inline void turnDegrees(float degrees, int8_t speedL, int8_t speedR) { jbc_motor_turn_degrees((int32_t)degrees, speedL, speedR); }
    inline void setGeometry(float wheelDiameter, float axleTrack) { jbc_motor_set_geometry((int32_t)(wheelDiameter * 1000), (int32_t)(axleTrack * 1000)); }
    inline void setDriveBasePID(float distKp, float distKi, float distKd, float headKp, float headKi, float headKd) { 
      jbc_motor_set_pid((int32_t)(distKp * 1000), (int32_t)(distKi * 1000), (int32_t)(distKd * 1000), 
                        (int32_t)(headKp * 1000), (int32_t)(headKi * 1000), (int32_t)(headKd * 1000)); 
    }
    inline void setVoltBase(float volt_base) { jbc_motor_set_volt_base((int32_t)(volt_base * 1000)); }
    
    // --- 編碼器與除錯 ---
    inline void resetEncoders(uint8_t index) { jbc_motor_reset_encoder(index); }
    inline int32_t getEncoder(uint8_t index) { return jbc_motor_get_encoder(index); }

    inline void printDebugData() {
        Serial.print("TL:"); Serial.print(dbg_targetDistPos);
        Serial.print(" CL:"); Serial.print(dbg_currDistPos);
        Serial.print(" eD:"); Serial.print(dbg_distError);
        Serial.print(" eH:"); Serial.print(dbg_headError);
        Serial.print(" EL:"); Serial.print(dbg_encL);
        Serial.print(" ER:"); Serial.print(dbg_encR);
        Serial.print(" outL:"); Serial.print(dbg_outL);
        Serial.print(" outR:"); Serial.println(dbg_outR);
    }

    // --- LED 控制 ---
    inline void setLED(uint8_t index, uint8_t r, uint8_t g, uint8_t b) { jbc_led_set(index, r, g, b); }
    inline void clearLEDs() { jbc_led_clear(); }

    // --- 感測器與按鈕 ---
    inline uint16_t readLineSensor(uint8_t index) { return jbc_hw_read_line_sensor(index); }
    inline uint16_t getDistance() { return jbc_i2c_get_distance(); }
    inline uint16_t getBatteryVoltage() { return jbc_hw_get_battery_voltage(); }
    inline bool isButtonPressed() { return jbc_hw_is_button_pressed(); }

    // --- PS2 手把控制 ---
    inline bool isPS2Connected() { return jbc_ps2_is_connected(); }
    inline bool isPS2ButtonPressed(uint16_t mask) { return jbc_ps2_button_pressed(mask); }
    inline uint8_t getPS2Stick(uint8_t stick) { return jbc_ps2_get_stick(stick); }
    inline bool readPS2() { return jbc_ps2_read(); }

    // --- 伺服馬達 ---
    inline void setServo(uint8_t index, uint8_t angle) { jbc_servo_set(index, angle); }

    // --- OLED 螢幕（SSD1315，選購）：英文與數字，x 0~15 欄、y 0~3 列；名稱與安裝版 OpenBlock 積木產生的程式相同 ---
    inline void oled_begin() { jbc_oled_begin(); }
    inline void oled_clear() { jbc_oled_clear(); }
    inline void oled_setCursor(uint8_t x, uint8_t y) { jbc_oled_set_cursor(x, y); }
    inline void oled_print(const char* text) { jbc_oled_print_str(text); }
    inline void oled_print(const String& text) { jbc_oled_print_str(text.c_str()); }
    inline void oled_print(char c) { char s[2] = { c, 0 }; jbc_oled_print_str(s); }
    inline void oled_print(int value) { jbc_oled_print_long(value); }
    inline void oled_print(unsigned int value) { jbc_oled_print_ulong(value); }
    inline void oled_print(long value) { jbc_oled_print_long(value); }
    inline void oled_print(unsigned long value) { jbc_oled_print_ulong(value); }
    inline void oled_print(double value) { jbc_oled_print_double(value); }
};

extern JBC_Bot Bot;
#endif
