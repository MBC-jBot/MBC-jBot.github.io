#ifndef JBC_MOTOR_H
#define JBC_MOTOR_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_motor_init();
void jbc_motor_set_raw(uint8_t index, int8_t speed);
void jbc_motor_set(uint8_t index, int8_t speed);
void jbc_motor_set_both(int8_t speedL, int8_t speedR);
void jbc_motor_set_sync(int sync);
// parameters scaled by 1000 to maintain precision without floats
void jbc_motor_set_geometry(int32_t wheelDiameter_um, int32_t axleTrack_um);
void jbc_motor_set_pid(int32_t distKp_1k, int32_t distKi_1k, int32_t distKd_1k, int32_t headKp_1k, int32_t headKi_1k, int32_t headKd_1k);
void jbc_motor_compute_pid();
int32_t jbc_motor_get_encoder(uint8_t index);
void jbc_motor_reset_encoder(uint8_t index);
void jbc_motor_move_distance(int32_t cm, int8_t speedL, int8_t speedR);
void jbc_motor_turn_degrees(int32_t degrees, int8_t speedL, int8_t speedR);
void jbc_motor_set_volt_base(int32_t volt_base);

#ifdef __cplusplus
}
#endif

// Debug variables (extern for printing in wrapper if needed)
extern int32_t dbg_targetDistPos, dbg_currDistPos, dbg_distError;
extern int32_t dbg_targetHeadPos, dbg_currHeadPos, dbg_headError;
extern int32_t dbg_outL, dbg_outR;
extern int32_t dbg_encL, dbg_encR;

#endif // JBC_MOTOR_H
