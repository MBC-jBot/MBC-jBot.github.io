#ifndef JBC_CONFIG_H
#define JBC_CONFIG_H

#include <Arduino.h>

#ifndef TW_START
#define TW_START     0x08
#define TW_REP_START 0x10
#define TW_MT_SLA_ACK 0x18
#define TW_MR_SLA_ACK 0x40
#define TW_MT_DATA_ACK 0x28
#endif

// --- 硬體腳位定義 ---
#define PIN_UART_RX     0
#define PIN_UART_TX     1
#define PIN_ENC_L_A     2       
#define PIN_ENC_L_B     4       
#define PIN_ENC_R_A     3       
#define PIN_ENC_R_B     7       
#define PIN_MOTOR_L_PWM1 10     
#define PIN_MOTOR_L_PWM2 9      
#define PIN_LED_RGB     8       
#define PIN_MOTOR_R_PWM1 5      
#define PIN_MOTOR_R_PWM2 6     

#define PIN_SPI_MOSI    11 
#define PIN_SPI_MISO    12 
#define PIN_SPI_SCK     13 
#define PIN_PS2_SS      A0 

#define PIN_SERVO_1     A1
#define PIN_SERVO_2     A2
#define PIN_BAT_BTN     A3 
#define PIN_I2C_SDA     A4
#define PIN_I2C_SCL     A5
#define PIN_SENSOR_L    A7 
#define PIN_SENSOR_R    A6 

// --- 常數定義 ---
#define MOTOR_L 0
#define MOTOR_R 1
#define ENC_L 0
#define ENC_R 1
#define ENC_AVG 2 
#define ENC_ALL 3 
#define BRAKE 127
#define SENSOR_L 0
#define SENSOR_R 1
#define SERVO_1 0
#define SERVO_2 1

#define PSB_SELECT      0x0001
#define PSB_L3          0x0002
#define PSB_R3          0x0004
#define PSB_START       0x0008
#define PSB_PAD_UP      0x0010
#define PSB_PAD_RIGHT   0x0020
#define PSB_PAD_DOWN    0x0040
#define PSB_PAD_LEFT    0x0080
#define PSB_L2          0x0100
#define PSB_R2          0x0200
#define PSB_L1          0x0400
#define PSB_R1          0x0800
#define PSB_TRIANGLE    0x1000
#define PSB_CIRCLE      0x2000
#define PSB_CROSS       0x4000
#define PSB_SQUARE      0x8000
#define PSS_RX 0
#define PSS_RY 1
#define PSS_LX 2
#define PSS_LY 3

#endif // JBC_CONFIG_H
