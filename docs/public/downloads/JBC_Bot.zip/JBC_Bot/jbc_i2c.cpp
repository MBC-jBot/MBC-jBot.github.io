#include "jbc_i2c.h"
#include <avr/pgmspace.h>

static struct {
  bool laserInitialized : 1;
  bool i2cError : 1;
} _i2cStatus = {0, 0};

static uint8_t _laser_stop_variable = 0;
static uint16_t _last_valid_dist = 8190;

static void _i2c_core_init() {
  TWBR = 72;
  TWSR = 0;
}

static uint8_t _i2c_start(uint8_t address) {
  TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
  uint32_t timeout = 0;
  while (!(TWCR & (1 << TWINT))) {
    if (++timeout > 50000) { _i2cStatus.i2cError = 1; return 1; }
  }
  if ((TWSR & 0xF8) != TW_START && (TWSR & 0xF8) != TW_REP_START) {
    _i2cStatus.i2cError = 1; return 1;
  }
  TWDR = address;
  TWCR = (1 << TWINT) | (1 << TWEN);
  timeout = 0;
  while (!(TWCR & (1 << TWINT))) {
    if (++timeout > 50000) { _i2cStatus.i2cError = 1; return 1; }
  }
  if ((TWSR & 0xF8) != TW_MT_SLA_ACK && (TWSR & 0xF8) != TW_MR_SLA_ACK) {
    _i2cStatus.i2cError = 1; return 1;
  }
  return 0;
}

static void _i2c_stop() {
  TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
  for (volatile uint8_t i = 0; i < 100; i++);
}

static uint8_t _i2c_write(uint8_t data) {
  TWDR = data;
  TWCR = (1 << TWINT) | (1 << TWEN);
  uint32_t timeout = 0;
  while (!(TWCR & (1 << TWINT))) {
    if (++timeout > 50000) { _i2cStatus.i2cError = 1; return 1; }
  }
  uint8_t error = ((TWSR & 0xF8) != TW_MT_DATA_ACK);
  if (error) _i2cStatus.i2cError = 1;
  return error;
}

static uint8_t _i2c_read(uint8_t ack) {
  TWCR = (1 << TWINT) | (1 << TWEN) | (ack ? (1 << TWEA) : 0);
  uint32_t timeout = 0;
  while (!(TWCR & (1 << TWINT))) {
    if (++timeout > 50000) { _i2cStatus.i2cError = 1; return 0; }
  }
  return TWDR;
}

static void _i2c_writeReg(uint8_t reg, uint8_t val) {
  if (_i2c_start(0x52) == 0) {
    if (_i2c_write(reg) == 0) _i2c_write(val);
    _i2c_stop();
  } else { _i2c_stop(); }
}

static uint8_t _i2c_readReg(uint8_t reg) {
  uint8_t val = 0;
  if (_i2c_start(0x52) == 0) {
    if (_i2c_write(reg) == 0) {
      if (_i2c_start(0x53) == 0) val = _i2c_read(0);
    }
    _i2c_stop();
  }
  return val;
}

static uint16_t _i2c_readReg16(uint8_t reg) {
  uint16_t val = 0;
  if (_i2c_start(0x52) == 0) {
    if (_i2c_write(reg) == 0) {
      if (_i2c_start(0x53) == 0) {
        val = (uint16_t)_i2c_read(1) << 8;
        val |= _i2c_read(0);
      }
    }
    _i2c_stop();
  }
  return val;
}

static const uint8_t laser_init_seq1[] PROGMEM = {
  0x88, 0x00, 0x80, 0x01, 0xFF, 0x01, 0x00, 0x00
};
static const uint8_t laser_init_seq2[] PROGMEM = {
  0x00, 0x01, 0xFF, 0x00, 0x80, 0x00, 0x0A, 0x04,
  0x84, 0x00, 0x0B, 0x01, 0x01, 0x01, 0x00, 0x41
};
static const uint8_t laser_init_seq3[] PROGMEM = {
  0x0B, 0x01, 0x01, 0x02, 0x00, 0x01
};
static const uint8_t laser_init_seq4[] PROGMEM = {
  0x0B, 0x01, 0x01, 0xE8, 0x80, 0x01, 0xFF, 0x01, 0x00, 0x00
};
static const uint8_t laser_init_seq5[] PROGMEM = {
  0x00, 0x01, 0xFF, 0x00, 0x80, 0x00, 0x00, 0x02
};

static void _send_seq(const uint8_t* seq, uint8_t len) {
  for (uint8_t i = 0; i < len; i += 2) {
    if (_i2cStatus.i2cError) break;
    _i2c_writeReg(pgm_read_byte(&seq[i]), pgm_read_byte(&seq[i+1]));
  }
}

static void _initLaser() {
  if (_i2cStatus.laserInitialized) return;
  _i2cStatus.i2cError = 0;
  _i2c_core_init();

  if (_i2c_readReg(0xC0) != 0xEE || _i2cStatus.i2cError) return;
  
  _send_seq(laser_init_seq1, sizeof(laser_init_seq1));
  _laser_stop_variable = _i2c_readReg(0x91);
  _send_seq(laser_init_seq2, sizeof(laser_init_seq2));
  
  while (!(_i2c_readReg(0x13) & 0x07) && !_i2cStatus.i2cError);
  
  _send_seq(laser_init_seq3, sizeof(laser_init_seq3));
  
  while (!(_i2c_readReg(0x13) & 0x07) && !_i2cStatus.i2cError);
  
  _send_seq(laser_init_seq4, sizeof(laser_init_seq4));
  _i2c_writeReg(0x91, _laser_stop_variable);
  _send_seq(laser_init_seq5, sizeof(laser_init_seq5));

  if (!_i2cStatus.i2cError) _i2cStatus.laserInitialized = 1;
}

void jbc_i2c_init() {
  _i2c_core_init();
}

uint16_t jbc_i2c_get_distance() {
  if (!_i2cStatus.laserInitialized) _initLaser();
  if (!_i2cStatus.laserInitialized) return 65535;

  _i2cStatus.i2cError = 0; 
  uint8_t status = _i2c_readReg(0x13);

  if (_i2cStatus.i2cError) {
    _i2cStatus.laserInitialized = 0;
    return 65535;
  }

  if (!(status & 0x07)) return _last_valid_dist;

  uint16_t dist = _i2c_readReg16(0x1E);
  if (_i2cStatus.i2cError) {
    _i2cStatus.laserInitialized = 0;
    return 65535;
  }

  _i2c_writeReg(0x0B, 0x01);
  if (dist == 0 || dist > 8000) return _last_valid_dist;

  _last_valid_dist = dist;
  return dist;
}

bool jbc_i2c_has_error() {
  return _i2cStatus.i2cError;
}

// ---- 通用寫入（OLED 等）：保存並還原雷射的錯誤旗標，別的裝置沒接不會讓雷射看起來出錯 ----
static bool _txSavedError = 0;

bool jbc_i2c_tx_begin(uint8_t addr7) {
  _txSavedError = _i2cStatus.i2cError;
  return _i2c_start(addr7 << 1) == 0;
}

void jbc_i2c_tx_write(uint8_t data) {
  _i2c_write(data);
}

void jbc_i2c_tx_end() {
  _i2c_stop();
  _i2cStatus.i2cError = _txSavedError;
}
