#include "jbc_led.h"
#include <util/atomic.h>
#include <util/delay.h>

#include "jbc_hw.h"

extern "C" {
  bool jbc_ps2_is_attempted(void) __attribute__((weak));
  bool jbc_ps2_is_connected(void) __attribute__((weak));
  bool jbc_ps2_is_active(void) __attribute__((weak));
}

static uint8_t _ledBuffer[12];
static uint8_t _userLEDColor[4][3]; // [index][r, g, b]

static struct {
  bool manualLED0 : 1;
  bool manualLED1 : 1;
  bool manualLED2 : 1;
  bool manualStatusLED : 1;
  bool led0Toggle : 1;
  bool led1Toggle : 1;
  bool led2Toggle : 1;
  bool led3Toggle : 1;
} _ledStatus = {0,0,0,0,0,0,0,0};

void jbc_led_init() {
  DDRB |= (1 << 0); // PB0 (Pin 8) as output for WS2812
  jbc_led_clear();
}

void jbc_led_set(uint8_t index, uint8_t r, uint8_t g, uint8_t b) {
  if (index > 3) return;

  uint8_t os = (index << 1) + index;
  _ledBuffer[os] = g;
  _ledBuffer[os + 1] = r;
  _ledBuffer[os + 2] = b;

  _userLEDColor[index][0] = r;
  _userLEDColor[index][1] = g;
  _userLEDColor[index][2] = b;

  if (index == 0) _ledStatus.manualLED0 = 1;
  else if (index == 1) _ledStatus.manualLED1 = 1;
  else if (index == 2) _ledStatus.manualLED2 = 1;
  else if (index == 3) _ledStatus.manualStatusLED = 1;

  jbc_led_update();
}

void jbc_led_clear() {
  for (int i = 0; i < 12; i++) _ledBuffer[i] = 0;
  _ledStatus.manualLED0 = 0;
  _ledStatus.manualLED1 = 0;
  _ledStatus.manualLED2 = 0;
  _ledStatus.manualStatusLED = 0;
  jbc_led_show_asm();
}

void jbc_led_update() {
  static unsigned long lastLEDUpdate = 0;
  if (millis() - lastLEDUpdate < 30) return; 
  lastLEDUpdate = millis();

  uint8_t *p = _ledBuffer;

  if (jbc_hw_is_low_bat()) {
    uint8_t val = ((millis() >> 9) & 1) ? 50 : 0;
    p[0] = 0; p[1] = val; p[2] = 0;
    p[3] = 0; p[4] = val; p[5] = 0;
    p[6] = 0; p[7] = val; p[8] = 0;
    p[9] = 0; p[10] = val; p[11] = 0;
    jbc_led_show_asm();
    return;
  }

  // --- LED 0 ---
  if (jbc_hw_is_line_sensor_active() && _ledStatus.manualLED0) {
    _ledStatus.led0Toggle = !_ledStatus.led0Toggle;
    if (_ledStatus.led0Toggle) {
      _ledBuffer[0] = _userLEDColor[0][1];
      _ledBuffer[1] = _userLEDColor[0][0];
      _ledBuffer[2] = _userLEDColor[0][2];
    } else {
      _ledBuffer[0] = 0;
      _ledBuffer[1] = jbc_hw_get_sensor_brightness(0);
      _ledBuffer[2] = 0;
    }
  }

  // --- LED 1 ---
  if (jbc_hw_is_line_sensor_active() && _ledStatus.manualLED1) {
    _ledStatus.led1Toggle = !_ledStatus.led1Toggle;
    if (_ledStatus.led1Toggle) {
      _ledBuffer[3] = _userLEDColor[1][1];
      _ledBuffer[4] = _userLEDColor[1][0];
      _ledBuffer[5] = _userLEDColor[1][2];
    } else {
      _ledBuffer[3] = 0;
      _ledBuffer[4] = jbc_hw_get_sensor_brightness(1);
      _ledBuffer[5] = 0;
    }
  }

  // --- LED 2 ---
  if (jbc_hw_is_button_pressed() && !_ledStatus.manualLED2) {
    _ledBuffer[6] = 20; _ledBuffer[7] = 20; _ledBuffer[8] = 0;
  } else if (jbc_hw_is_button_pressed() && _ledStatus.manualLED2) {
    _ledStatus.led2Toggle = !_ledStatus.led2Toggle;
    if (_ledStatus.led2Toggle) {
      _ledBuffer[6] = _userLEDColor[2][1];
      _ledBuffer[7] = _userLEDColor[2][0];
      _ledBuffer[8] = _userLEDColor[2][2];
    } else {
      _ledBuffer[6] = 20; _ledBuffer[7] = 20; _ledBuffer[8] = 0;
    }
  } else if (!jbc_hw_is_button_pressed() && _ledStatus.manualLED2) {
    _ledBuffer[6] = _userLEDColor[2][1];
    _ledBuffer[7] = _userLEDColor[2][0];
    _ledBuffer[8] = _userLEDColor[2][2];
  } else {
    _ledBuffer[6] = 0; _ledBuffer[7] = 0; _ledBuffer[8] = 0;
  }

  // --- LED 3 ---
  if (jbc_ps2_is_attempted && jbc_ps2_is_attempted()) {
    bool toggle = true;
    if (_ledStatus.manualStatusLED) {
      _ledStatus.led3Toggle = !_ledStatus.led3Toggle;
      toggle = _ledStatus.led3Toggle;
    }
    
    if (toggle && _ledStatus.manualStatusLED) {
      _ledBuffer[9] = _userLEDColor[3][1];
      _ledBuffer[10] = _userLEDColor[3][0];
      _ledBuffer[11] = _userLEDColor[3][2];
    } else {
      if (jbc_ps2_is_connected && jbc_ps2_is_connected()) {
        if (jbc_ps2_is_active && jbc_ps2_is_active()) {
          _ledBuffer[9] = 0; _ledBuffer[10] = 0; _ledBuffer[11] = 50;
        } else {
          _ledBuffer[9] = 20; _ledBuffer[10] = 0; _ledBuffer[11] = 0;
        }
      } else {
        if ((millis() >> 9) & 1) {
          _ledBuffer[9] = 20; _ledBuffer[10] = 20; _ledBuffer[11] = 0;
        } else {
          _ledBuffer[9] = 0; _ledBuffer[10] = 0; _ledBuffer[11] = 0;
        }
      }
    }
  }

  jbc_led_show_asm();
}

void jbc_led_show_asm() {
  uint8_t *ptr = _ledBuffer;
  uint16_t n = 12;
  volatile uint8_t *port = &PORTB;
  uint8_t pinMask = 1;
  uint8_t hi = PORTB | pinMask;
  uint8_t lo = PORTB & ~pinMask;

  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    asm volatile("head20:\n\t"
                 "ld __tmp_reg__, %a0+\n\t"
                 "ldi r24, 8\n\t"
                 "nextbit20:\n\t"
                 "st %a1, %2\n\t"
                 "sbrs __tmp_reg__, 7\n\t"
                 "rjmp wait20\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "st %a1, %2\n\t"
                 "rjmp bit1_end20\n\t"
                 "wait20:\n\t"
                 "st %a1, %3\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "bit1_end20:\n\t"
                 "nop\n\t"
                 "st %a1, %3\n\t"
                 "nop\n\t"
                 "nop\n\t"
                 "lsl __tmp_reg__\n\t"
                 "dec r24\n\t"
                 "brne nextbit20\n\t"
                 "dec %4\n\t"
                 "brne head20\n\t"
                 : "+z"(ptr)
                 : "e"(port), "r"(hi), "r"(lo), "r"(n)
                 : "r24");
  }
  _delay_us(80);
}
