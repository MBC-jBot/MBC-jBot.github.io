#ifndef JBC_I2C_H
#define JBC_I2C_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_i2c_init();
uint16_t jbc_i2c_get_distance();
bool jbc_i2c_has_error();

// 通用寫入（給 OLED 等其他 I2C 裝置用）：begin → write… → end，一定要成對呼叫 end。
// 不會動到雷射的錯誤旗標；begin 回傳 false＝裝置沒回應（沒接）。addr7＝7 位元位址。
bool jbc_i2c_tx_begin(uint8_t addr7);
void jbc_i2c_tx_write(uint8_t data);
void jbc_i2c_tx_end();

#ifdef __cplusplus
}
#endif

#endif // JBC_I2C_H
