#include "JBC_Bot.h"

extern "C" {
  void jbc_motor_init(void) __attribute__((weak));
  void jbc_servo_init(void) __attribute__((weak));
  void jbc_led_init(void) __attribute__((weak));
  void jbc_i2c_init(void) __attribute__((weak));
  void jbc_ps2_init(void) __attribute__((weak));
}

JBC_Bot Bot;

JBC_Bot::JBC_Bot() {
  // 建構子保留為空，避免在全域變數初始化時期依賴硬體狀態
}

void JBC_Bot::begin() {
  jbc_motor_init();
  jbc_servo_init();
  jbc_led_init();
  jbc_i2c_init();
  jbc_ps2_init();
  
  // 硬體核心永遠會初始化 (設定ADC等)
  jbc_hw_init();

  sei();
  clearLEDs();

  // 檢查是否使用電池供電 (電壓 > 3V)
  // 如果是 USB 供電 (電池未接上)，A3電壓會接近 0，導致 isButtonPressed() 永遠為 true
  // 為了防止卡死，我們只有在電池電壓 > 3000mV 時才等待按鈕
  if (getBatteryVoltage() > 3000) {
    // 等待按鈕按下再啟動的邏輯
    while (!isButtonPressed()) {
      if ((millis() >> 9) & 1) {
        jbc_led_set(2, 0, 10, 0); // 閃爍綠燈表示等待中 (簡化)
      } else {
        jbc_led_set(2, 0, 0, 0);
      }
      delay(10);
    }

    while (isButtonPressed()) {
      jbc_led_set(2, 20, 0, 0);
      delay(10);
    }
  }

  clearLEDs();
}

