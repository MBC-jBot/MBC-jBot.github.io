#include "jbc_ps2.h"

#include <util/atomic.h>
#include <util/delay.h>

extern "C" void jbc_led_update(void) __attribute__((weak));

static uint8_t PS2data[9] = {0,0,0, 0xFF,0xFF, 128,128,128,128};

static struct {
  bool ps2Connected : 1;
  bool ps2Active : 1;
  bool ps2Configured : 1;
  bool ps2Attempted : 1;
} _ps2Status = {0, 0, 0, 0};

static unsigned long _lastPS2PollTime = 0;

static uint8_t _spiTransfer(uint8_t data) {
  SPDR = data;
  while (!(SPSR & (1 << SPIF)));
  return SPDR;
}

static void _ps2_config() {
  PORTC &= ~(1 << 0);
  _delay_us(20);
  _spiTransfer(0x01); _spiTransfer(0x43); _spiTransfer(0x00);
  _spiTransfer(0x01); _spiTransfer(0x00);
  PORTC |= (1 << 0);
  delay(10);

  PORTC &= ~(1 << 0);
  _delay_us(20);
  _spiTransfer(0x01); _spiTransfer(0x44); _spiTransfer(0x00);
  _spiTransfer(0x01); _spiTransfer(0x03); _spiTransfer(0x00);
  _spiTransfer(0x00); _spiTransfer(0x00); _spiTransfer(0x00);
  PORTC |= (1 << 0);
  delay(10);

  PORTC &= ~(1 << 0);
  _delay_us(20);
  _spiTransfer(0x01); _spiTransfer(0x43); _spiTransfer(0x00);
  _spiTransfer(0x00); _spiTransfer(0x5A); _spiTransfer(0x5A);
  _spiTransfer(0x5A); _spiTransfer(0x5A); _spiTransfer(0x5A);
  PORTC |= (1 << 0);
  delay(10);
}

static void _pollPS2Hardware() {
  _ps2Status.ps2Attempted = 1;

  PORTC &= ~(1 << 0);
  _delay_us(50);

  _spiTransfer(0x01); _delay_us(10);
  uint8_t mode = _spiTransfer(0x42); _delay_us(10);
  _spiTransfer(0x00); _delay_us(10);

  PS2data[3] = _spiTransfer(0x00); _delay_us(10);
  PS2data[4] = _spiTransfer(0x00); _delay_us(10);
  PS2data[5] = _spiTransfer(0x00); _delay_us(10);
  PS2data[6] = _spiTransfer(0x00); _delay_us(10);
  PS2data[7] = _spiTransfer(0x00); _delay_us(10);
  PS2data[8] = _spiTransfer(0x00);

  PORTC |= (1 << 0);

  if (mode == 0xFF || mode == 0x00) {
    _ps2Status.ps2Connected = false;
    _ps2Status.ps2Configured = false;
  } else {
    _ps2Status.ps2Connected = true;
    if (mode != 0x73 && !_ps2Status.ps2Configured) {
      _ps2_config();
      _ps2Status.ps2Configured = true;
    }
  }

  bool active = false;
  if (PS2data[3] != 0xFF || PS2data[4] != 0xFF) active = true;

  if (mode == 0x73) {
    if (abs(PS2data[5] - 128) > 20 || abs(PS2data[6] - 128) > 20 ||
        abs(PS2data[7] - 128) > 20 || abs(PS2data[8] - 128) > 20)
      active = true;
  }

  _ps2Status.ps2Active = active;
  if (jbc_led_update) jbc_led_update();
}

static void _autoUpdatePS2() {
  _ps2Status.ps2Attempted = 1;
  if (millis() - _lastPS2PollTime >= 16) {
    _pollPS2Hardware();
    _lastPS2PollTime = millis();
  }
}

void jbc_ps2_init() {
  DDRC |= (1 << 0); // PS2 SS as output
  PORTC |= (1 << 0); // High
  
  DDRB |= (1 << 3) | (1 << 5); // PB3 (MOSI), PB5 (SCK) as output
  DDRB &= ~(1 << 4); // PB4 (MISO) as input
  PORTB |= (1 << 4); // Pullup on MISO
  PORTB |= (1 << 5); // Pullup on SCK
  
  SPCR = (1 << SPE) | (1 << DORD) | (1 << MSTR) | (1 << CPOL) | (1 << CPHA) | (1 << SPR1);
  SPSR = 0;
}

bool jbc_ps2_is_connected() {
  _autoUpdatePS2();
  return _ps2Status.ps2Connected;
}

bool jbc_ps2_is_active() {
  return _ps2Status.ps2Active;
}

bool jbc_ps2_is_attempted() {
  return _ps2Status.ps2Attempted;
}

bool jbc_ps2_button_pressed(uint16_t mask) {
  _autoUpdatePS2();
  if (!_ps2Status.ps2Connected) return false;
  uint16_t buttons = (PS2data[4] << 8) | PS2data[3];
  return (~buttons & mask);
}

uint8_t jbc_ps2_get_stick(uint8_t stick) {
  _autoUpdatePS2();
  if (!_ps2Status.ps2Connected) return 128;
  if (stick > 3) return 128;

  uint8_t raw_val = PS2data[5 + stick];
  if (stick == PSS_RY || stick == PSS_LY) {
    return 255 - raw_val;
  }
  return raw_val;
}

bool jbc_ps2_read() {
  _pollPS2Hardware();
  return _ps2Status.ps2Connected;
}
