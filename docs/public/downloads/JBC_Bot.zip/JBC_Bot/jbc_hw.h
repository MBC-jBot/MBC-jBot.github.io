#ifndef JBC_HW_H
#define JBC_HW_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_hw_init();
void jbc_hw_check_battery();
uint16_t jbc_hw_get_battery_voltage();
bool jbc_hw_is_low_bat();
bool jbc_hw_is_button_pressed();
uint16_t jbc_hw_read_line_sensor(uint8_t index);
bool jbc_hw_is_line_sensor_active();
uint8_t jbc_hw_get_sensor_brightness(uint8_t index);

#ifdef __cplusplus
}
#endif

#endif // JBC_HW_H
