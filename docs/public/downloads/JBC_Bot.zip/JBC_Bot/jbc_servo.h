#ifndef JBC_SERVO_H
#define JBC_SERVO_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_servo_init();
void jbc_servo_set(uint8_t index, uint8_t angle);

#ifdef __cplusplus
}
#endif

#endif // JBC_SERVO_H
