#ifndef JBC_LED_H
#define JBC_LED_H

#include <Arduino.h>
#include "jbc_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void jbc_led_init();
void jbc_led_set(uint8_t index, uint8_t r, uint8_t g, uint8_t b);
void jbc_led_clear();
void jbc_led_update();
void jbc_led_show_asm();

#ifdef __cplusplus
}
#endif

#endif // JBC_LED_H
