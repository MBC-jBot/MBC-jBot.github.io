#include "jbc_hw.h"

extern "C" void jbc_led_update(void) __attribute__((weak));

static struct {
  bool lowBat : 1;
  bool buttonPressed : 1;
  bool lineSensorActive : 1;
} _hwStatus = {0, 0, 0};

static uint8_t _sensorLEDBrightness[2] = {0, 0};

static uint16_t _readADC(uint8_t ch) {
  ADMUX = (1 << REFS0) | (ch & 0x07);
  ADCSRA |= (1 << ADSC);
  while (ADCSRA & (1 << ADSC));
  return ADC;
}

void jbc_hw_init() {
  ADCSRA = 0x86;
}

uint16_t jbc_hw_get_battery_voltage() {
  uint32_t val = _readADC(3); // PIN_BAT_BTN is A3
  return (uint16_t)((val << 3) + (val << 1));
}

void jbc_hw_check_battery() {
  static unsigned long lastCheck = 0;
  if (millis() - lastCheck < 1000) return;
  lastCheck = millis();

  uint16_t adc = _readADC(3);
  if (adc < 50 || adc > 480)
    _hwStatus.lowBat = false;
  else if (adc < 328)
    _hwStatus.lowBat = true;
  else
    _hwStatus.lowBat = false;
}

bool jbc_hw_is_low_bat() {
  return _hwStatus.lowBat;
}

bool jbc_hw_is_button_pressed() {
  bool pressed = (_readADC(3) < 50);
  if (pressed != _hwStatus.buttonPressed) {
    _hwStatus.buttonPressed = pressed;
    if (jbc_led_update) jbc_led_update();
  }
  return pressed;
}

uint16_t jbc_hw_read_line_sensor(uint8_t index) {
  uint8_t i = index & 1;
  uint16_t val = _readADC(i == 0 ? 7 : 6); // A7 for L, A6 for R
  int16_t temp = val - 100;
  if (temp < 0) temp = 0;

  int8_t br = temp >> 5;
  if (br > 20) br = 20;

  _hwStatus.lineSensorActive = 1;
  _sensorLEDBrightness[i] = br;

  if (jbc_led_update) jbc_led_update();
  return val;
}

bool jbc_hw_is_line_sensor_active() {
  return _hwStatus.lineSensorActive;
}

uint8_t jbc_hw_get_sensor_brightness(uint8_t index) {
  return _sensorLEDBrightness[index & 1];
}
