#include "jbc_motor.h"
#include <avr/interrupt.h>
#include <util/atomic.h>

#include "jbc_hw.h"

extern "C" void jbc_led_update(void) __attribute__((weak));
static volatile int32_t _encCount[2] = {0, 0};
static volatile uint8_t _lastPortD = 0;

static int _syncMode = 1;
static float _wheelDiameter = 34.0;
static float _axleTrack = 91.0;
static float _ticksPerMm = 640.0 / (3.14159 * 34.0);
static float _ticksPerDegree = (91.0 * 3.14159 / 360.0) * (640.0 / (3.14159 * 34.0));

static int32_t _volt_base_mv = 0; // 電壓基準 (0 代表關閉)

static int16_t jbc_volt_scale(int16_t pwm) {
  if (_volt_base_mv <= 0 || pwm == 0 || pwm == BRAKE) return pwm;
  
  uint16_t current_v = jbc_hw_get_battery_voltage();
  if (current_v < 1000) current_v = 1000;
  
  int32_t scaled = ((int32_t)pwm * _volt_base_mv) / current_v;
  if (scaled > 100) return 100;
  if (scaled < -100) return -100;
  return (int16_t)scaled;
}

static int32_t _targetDistanceRate_Q8 = 0;
static int32_t _targetHeadingRate_Q8 = 0;
static int32_t _targetDistancePos_Q8 = 0;
static int32_t _targetHeadingPos_Q8 = 0;
static int32_t _distErrorSum_Q8 = 0;
static int32_t _headErrorSum_Q8 = 0;
static int32_t _prevDistError_Q8 = 0;
static int32_t _prevHeadError_Q8 = 0;

static int32_t _estSpeedL_Q8 = 0;
static int32_t _estSpeedR_Q8 = 0;
static int32_t _estCountL = 0;
static int32_t _estCountR = 0;

// PID constants scaled by 65536 (Q16). Pre-multiplied by dt (0.005) where needed.
// distKp = 1.0 -> 65536
// distKi_dt = 0.1 * 0.005 = 0.0005 -> 32
// distKd_over_dt = 0.01 / 0.005 = 2.0 -> 131072
static int32_t _distKp_Q16 = 65536, _distKi_dt_Q16 = 32, _distKd_over_dt_Q16 = 131072;
static int32_t _headKp_Q16 = 98304, _headKi_dt_Q16 = 163, _headKd_over_dt_Q16 = 131072;

static int32_t _ticksPerMm_Q8 = 1534;    // 5.9919 * 256
static int32_t _ticksPerDegree_Q8 = 1218; // 4.757 * 256

int32_t dbg_targetDistPos, dbg_currDistPos, dbg_distError;
int32_t dbg_targetHeadPos, dbg_currHeadPos, dbg_headError;
int32_t dbg_outL, dbg_outR;
int32_t dbg_encL, dbg_encR;

ISR(PCINT2_vect) {
  uint8_t currentPIND = PIND;
  uint8_t lastPIND = _lastPortD;
  uint8_t changed = currentPIND ^ lastPIND;

  if (changed & 0x0C) {
    int8_t dir = ((lastPIND >> 2) & 1) ^ ((currentPIND >> 3) & 1);
    int8_t other = ((currentPIND >> 2) & 1) ^ ((lastPIND >> 3) & 1);
    _encCount[MOTOR_L] += (dir - other);
  }

  if (changed & 0x90) {
    int8_t dir = ((lastPIND >> 4) & 1) ^ ((currentPIND >> 7) & 1);
    int8_t other = ((currentPIND >> 4) & 1) ^ ((lastPIND >> 7) & 1);
    _encCount[MOTOR_R] -= (dir - other);
  }

  _lastPortD = currentPIND;
}

void jbc_motor_init() {
  DDRD |= (1 << 5) | (1 << 6);
  DDRB |= (1 << 1) | (1 << 2);
  PORTD |= (1 << 2) | (1 << 3) | (1 << 4) | (1 << 7);

  TCCR0A = 0xA3;
  TCCR0B = 0x03;
  TCCR1A = 0xA1;
  TCCR1B = 0x09;

  PCICR |= (1 << PCIE2);
  PCMSK2 |= (1 << 2) | (1 << 3) | (1 << 4) | (1 << 7);
  _lastPortD = PIND;
}

extern "C" {
  void (* const p_jbc_motor_init)(void) = jbc_motor_init;
}

void jbc_motor_set_raw(uint8_t index, int8_t speed) {
  speed = (int8_t)jbc_volt_scale(speed); // 注入電壓調整
  uint8_t pwm_val = 0;
  bool is_brake = (speed == BRAKE);

  if (!is_brake && speed != 0) {
    int16_t s = speed;
    if (s < 0) s = -s;
    if (s > 100) s = 100;
    pwm_val = (s << 1) + (s >> 1);
  }

  if (index == MOTOR_L) {
    if (is_brake) { OCR1A = 255; OCR1B = 255; }
    else if (speed > 0) { OCR1A = pwm_val; OCR1B = 0; }
    else if (speed < 0) { OCR1A = 0; OCR1B = pwm_val; }
    else { OCR1A = 255; OCR1B = 255; }
  }

  if (index == MOTOR_R) {
    if (is_brake) { OCR0B = 255; OCR0A = 255; }
    else if (speed > 0) { OCR0B = pwm_val; OCR0A = 0; }
    else if (speed < 0) { OCR0B = 0; OCR0A = pwm_val; }
    else { OCR0B = 255; OCR0A = 255; }
  }
}

void jbc_motor_set_sync(int sync) {
  if (sync && !_syncMode) {
    _distErrorSum_Q8 = 0; _headErrorSum_Q8 = 0;
    _prevDistError_Q8 = 0; _prevHeadError_Q8 = 0;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      _estCountL = _encCount[0];
      _estCountR = _encCount[1];
    }
    _targetDistancePos_Q8 = ((_estCountL + _estCountR) * 256) / 2;
    _targetHeadingPos_Q8 = ((_estCountL - _estCountR) * 256) / 2;
  }
  _syncMode = sync;
}

// 假設傳入值為實際直徑與輪距的 1000 倍 (整數化)
void jbc_motor_set_geometry(int32_t wheelDiameter_um, int32_t axleTrack_um) {
  if (wheelDiameter_um == 0) return;
  int32_t num = 640000;
  int32_t den = (3 * wheelDiameter_um) + (141 * (wheelDiameter_um / 1000));
  _ticksPerMm_Q8 = (num * 256) / den;
  
  _ticksPerDegree_Q8 = ((axleTrack_um / 100) * 314 * _ticksPerMm_Q8) / 36000;
}

// 傳入的 PID 參數為原始值的 1000 倍
void jbc_motor_set_pid(int32_t distKp_1k, int32_t distKi_1k, int32_t distKd_1k, int32_t headKp_1k, int32_t headKi_1k, int32_t headKd_1k) {
  _distKp_Q16 = (distKp_1k * 65536) / 1000;
  _distKi_dt_Q16 = (distKi_1k * 5 * 65536) / 1000000; // * 0.005
  _distKd_over_dt_Q16 = (distKd_1k * 65536 * 200) / 1000; // / 0.005 = * 200
  
  _headKp_Q16 = (headKp_1k * 65536) / 1000;
  _headKi_dt_Q16 = (headKi_1k * 5 * 65536) / 1000000;
  _headKd_over_dt_Q16 = (headKd_1k * 65536 * 200) / 1000;
}

void jbc_motor_compute_pid() {
  if (!_syncMode) return;

  int32_t currentEncL, currentEncR;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    currentEncL = _encCount[0];
    currentEncR = _encCount[1];
  }

  // measuredSpeed = (current - est) / 0.005 => (current - est) * 200
  // we do this in Q8 for speed
  int32_t measuredSpeedL_Q8 = (currentEncL - _estCountL) * 200 * 256;
  int32_t measuredSpeedR_Q8 = (currentEncR - _estCountR) * 200 * 256;
  
  // estSpeed = estSpeed * 179/256 + measuredSpeed * 77/256 => bitwise
  _estSpeedL_Q8 = (_estSpeedL_Q8 * 179 + measuredSpeedL_Q8 * 77) >> 8;
  _estSpeedR_Q8 = (_estSpeedR_Q8 * 179 + measuredSpeedR_Q8 * 77) >> 8;
  
  _estCountL = currentEncL;
  _estCountR = currentEncR;

  _targetDistancePos_Q8 += _targetDistanceRate_Q8;
  _targetHeadingPos_Q8 += _targetHeadingRate_Q8;

  int32_t currentDistancePos_Q8 = ((_estCountL + _estCountR) << 8) >> 1;
  int32_t currentHeadingPos_Q8 = ((_estCountL - _estCountR) << 8) >> 1;

  int32_t distError_Q8 = _targetDistancePos_Q8 - currentDistancePos_Q8;
  if (distError_Q8 > 25600) { // 100.0 * 256
    distError_Q8 = 25600;
    _targetDistancePos_Q8 = currentDistancePos_Q8 + 25600;
  } else if (distError_Q8 < -25600) {
    distError_Q8 = -25600;
    _targetDistancePos_Q8 = currentDistancePos_Q8 - 25600;
  }
  
  int32_t headError_Q8 = _targetHeadingPos_Q8 - currentHeadingPos_Q8;

  _distErrorSum_Q8 += distError_Q8;
  _headErrorSum_Q8 += headError_Q8;
  
  if (_distErrorSum_Q8 > 512000) _distErrorSum_Q8 = 512000; // 2000 * 256
  if (_distErrorSum_Q8 < -512000) _distErrorSum_Q8 = -512000;
  if (_headErrorSum_Q8 > 512000) _headErrorSum_Q8 = 512000;
  if (_headErrorSum_Q8 < -512000) _headErrorSum_Q8 = -512000;

  int32_t dDist_Q8 = distError_Q8 - _prevDistError_Q8;
  int32_t dHead_Q8 = headError_Q8 - _prevHeadError_Q8;
  _prevDistError_Q8 = distError_Q8;
  _prevHeadError_Q8 = headError_Q8;

  // Kp_Q16 降維為 Q8 以避免 32-bit * 32-bit 溢位
  // distKp_Q8 = _distKp_Q16 >> 8
  int32_t distKp_Q8 = _distKp_Q16 >> 8;
  int32_t distKi_Q8 = _distKi_dt_Q16 >> 8;
  int32_t distKd_Q8 = _distKd_over_dt_Q16 >> 8;
  
  int32_t headKp_Q8 = _headKp_Q16 >> 8;
  int32_t headKi_Q8 = _headKi_dt_Q16 >> 8;
  int32_t headKd_Q8 = _headKd_over_dt_Q16 >> 8;

  // Torque_Q8 = (Kp_Q8 * error_Q8 + Ki_Q8 * sum_Q8 + Kd_Q8 * dError_Q8)
  // 然後再 >> 8 來消除常數本身的放大，最後再 >> 8 把 Pos_Q8 降回標準值。 也就是 >> 16。
  int32_t distTorque = (distKp_Q8 * distError_Q8 + distKi_Q8 * _distErrorSum_Q8 + distKd_Q8 * dDist_Q8) >> 16;
  int32_t headTorque = (headKp_Q8 * headError_Q8 + headKi_Q8 * _headErrorSum_Q8 + headKd_Q8 * dHead_Q8) >> 16;

  // target rate is ticks/sec * 0.005 * 256. To get to 0-100 scale: (rate / 256 / 0.005) * 100 / 3000 = rate * 100 / (256 * 15) = rate * 10 / 384
  int32_t ffL = ((_targetDistanceRate_Q8 + _targetHeadingRate_Q8) * 10) / 384;
  int32_t ffR = ((_targetDistanceRate_Q8 - _targetHeadingRate_Q8) * 10) / 384;
  
  int32_t finalL = ffL + distTorque + headTorque;
  int32_t finalR = ffR + distTorque - headTorque;

  if (_targetDistanceRate_Q8 == 0 && _targetHeadingRate_Q8 == 0 && abs(distError_Q8) <= 1024 && abs(headError_Q8) <= 1024) {
    finalL = 0; finalR = 0;
    _distErrorSum_Q8 = 0; _headErrorSum_Q8 = 0;
  } else {
    if (finalL > 0) finalL += 15; else if (finalL < 0) finalL -= 15;
    if (finalR > 0) finalR += 15; else if (finalR < 0) finalR -= 15;
  }

  if (abs(finalL) < 8) finalL = 0;
  if (abs(finalR) < 8) finalR = 0;

  int32_t max_val = finalL > 0 ? finalL : -finalL;
  int32_t max_r = finalR > 0 ? finalR : -finalR;
  if (max_r > max_val) max_val = max_r;

  if (max_val > 100) {
    finalL = (finalL * 100) / max_val;
    finalR = (finalR * 100) / max_val;
  }

  if (finalL > 100) finalL = 100; if (finalL < -100) finalL = -100;
  if (finalR > 100) finalR = 100; if (finalR < -100) finalR = -100;

  dbg_targetDistPos = _targetDistancePos_Q8 / 256; dbg_currDistPos = currentDistancePos_Q8 / 256;
  dbg_distError = distError_Q8 / 256; dbg_headError = headError_Q8 / 256;
  dbg_outL = finalL; dbg_outR = finalR;
  dbg_encL = currentEncL; dbg_encR = currentEncR;

  jbc_motor_set_raw(MOTOR_L, (int8_t)finalL);
  jbc_motor_set_raw(MOTOR_R, (int8_t)finalR);
}

void jbc_motor_set(uint8_t index, int8_t speed) {
  jbc_hw_check_battery();
  if (_syncMode && speed == BRAKE) _syncMode = 0;
  jbc_motor_set_raw(index, speed);
  if (jbc_led_update) jbc_led_update();
}

void jbc_motor_set_both(int8_t speedL, int8_t speedR) {
  jbc_hw_check_battery();
  if (_syncMode) {
    if (speedL == BRAKE || speedR == BRAKE) {
      _syncMode = 0;
      jbc_motor_set_raw(MOTOR_L, speedL);
      jbc_motor_set_raw(MOTOR_R, speedR);
    } else {
      int32_t targetL = speedL * 30; // ticks/sec
      int32_t targetR = speedR * 30;
      // targetL_Q8 = targetL * 1.28 ~ targetL + (targetL >> 2) (which is 1.25)
      int32_t targetL_Q8 = targetL + (targetL >> 2);
      int32_t targetR_Q8 = targetR + (targetR >> 2);
      
      int32_t newDistanceRate_Q8 = (targetL_Q8 + targetR_Q8) >> 1;
      int32_t newHeadingRate_Q8 = (targetL_Q8 - targetR_Q8) >> 1;

      if (targetL == 0 && targetR == 0 && (_targetDistanceRate_Q8 != 0 || _targetHeadingRate_Q8 != 0)) {
         ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
            _targetDistancePos_Q8 = ((_encCount[0] + _encCount[1]) << 8) >> 1;
            _targetHeadingPos_Q8  = ((_encCount[0] - _encCount[1]) << 8) >> 1;
         }
         _distErrorSum_Q8 = 0; _headErrorSum_Q8 = 0;
         _prevDistError_Q8 = 0; _prevHeadError_Q8 = 0;
      }
      else if (newHeadingRate_Q8 == 0 && _targetHeadingRate_Q8 != 0) {
         ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
            _targetHeadingPos_Q8 = ((_encCount[0] - _encCount[1]) * 256) / 2;
         }
         _headErrorSum_Q8 = 0; _prevHeadError_Q8 = 0;
      }
      
      _targetDistanceRate_Q8 = newDistanceRate_Q8;
      _targetHeadingRate_Q8 = newHeadingRate_Q8;
    }
  } else {
    jbc_motor_set_raw(MOTOR_L, speedL);
    jbc_motor_set_raw(MOTOR_R, speedR);
  }
  if (jbc_led_update) jbc_led_update();
}

int32_t jbc_motor_get_encoder(uint8_t index) {
  int32_t val;
  if (index == ENC_AVG) { 
    int32_t l, r;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { l = _encCount[0]; r = _encCount[1]; }
    val = (l + r) >> 1; 
  } else {
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { val = _encCount[index & 1]; }
  }
  return val;
}

void jbc_motor_reset_encoder(uint8_t index) {
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    if (index == ENC_L || index == ENC_ALL) _encCount[0] = 0;
    if (index == ENC_R || index == ENC_ALL) _encCount[1] = 0;
  }
}

void jbc_motor_move_distance(int32_t mm, int8_t speedL, int8_t speedR) {
  if (mm == 0 || (speedL + speedR) == 0) return;
  mm = mm > 0 ? mm : -mm;
  if ((speedL + speedR) < 0) mm = -mm;

  // ticksToMove_Q8 = mm * _ticksPerMm_Q8
  int32_t ticksToMove_Q8 = mm * _ticksPerMm_Q8;
  
  jbc_motor_set_sync(1);
  int32_t currentEncL, currentEncR;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    currentEncL = _encCount[0];
    currentEncR = _encCount[1];
  }
  int32_t startPos_Q8 = ((currentEncL + currentEncR) << 8) >> 1;
  int32_t targetPos_Q8 = startPos_Q8 + ticksToMove_Q8;
  
  jbc_motor_set_both(speedL, speedR);
  
  while (true) {
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      currentEncL = _encCount[0];
      currentEncR = _encCount[1];
    }
    int32_t currPos_Q8 = ((currentEncL + currentEncR) << 8) >> 1;
    if (mm > 0 && currPos_Q8 >= targetPos_Q8) break;
    if (mm < 0 && currPos_Q8 <= targetPos_Q8) break;
    delay(5);
  }
  jbc_motor_set_both(BRAKE, BRAKE);
}

void jbc_motor_turn_degrees(int32_t degrees, int8_t speedL, int8_t speedR) {
  if (degrees == 0 || speedL == speedR) return;
  degrees = degrees > 0 ? degrees : -degrees;
  if (speedL < speedR) degrees = -degrees;

  int32_t ticksToTurn_Q8 = degrees * _ticksPerDegree_Q8;
  
  jbc_motor_set_sync(1);
  int32_t currentEncL, currentEncR;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    currentEncL = _encCount[0];
    currentEncR = _encCount[1];
  }
  int32_t startHeading_Q8 = ((currentEncL - currentEncR) << 8) >> 1;
  int32_t targetHeading_Q8 = startHeading_Q8 + ticksToTurn_Q8;
  
  jbc_motor_set_both(speedL, speedR);
  
  while (true) {
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      currentEncL = _encCount[0];
      currentEncR = _encCount[1];
    }
    int32_t currHeading_Q8 = ((currentEncL - currentEncR) << 8) >> 1;
    if (degrees > 0 && currHeading_Q8 >= targetHeading_Q8) break;
    if (degrees < 0 && currHeading_Q8 <= targetHeading_Q8) break;
    delay(5);
  }
  jbc_motor_set_both(BRAKE, BRAKE);
}

void jbc_motor_set_volt_base(int32_t volt_base_mv) {
  _volt_base_mv = volt_base_mv;
}
