#ifndef JBC_OLED_H
#define JBC_OLED_H

#include <Arduino.h>
#include "jbc_config.h"

// SSD1315 OLED 螢幕（0.49 吋 64x32，I2C 位址 0x3C，擴充包配件）
// 英文、數字與符號：8x16 字型，8 欄（x 0~7）x 2 列（y 0~1）；中文與其他字元顯示成 ?
// 第一次清除或顯示時會自動初始化，不用另外呼叫 begin

#ifdef __cplusplus
extern "C" {
#endif

void jbc_oled_begin();
void jbc_oled_clear();
void jbc_oled_set_cursor(uint8_t x, uint8_t y);
void jbc_oled_print_str(const char* text);
void jbc_oled_print_long(long value);
void jbc_oled_print_ulong(unsigned long value);
void jbc_oled_print_double(double value);

#ifdef __cplusplus
}
#endif

#endif // JBC_OLED_H
